package com.vzw.ccpa.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.Hashtable;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.MDC;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;

import com.vzw.pos.automation.drivers.BasePage;
import com.vzw.pos.automation.drivers.TapsiumHandler;
//import com.vzw.pos.automation.drivers.TapsiumTestSession;
import com.vzw.pos.automation.exceptions.NoDataFound;
import com.vzw.pos.automation.latest.reports.ReportMigrator;
import com.vzw.pos.automation.latest.reports.ResultUtil;
import com.vzw.pos.automation.reports.CustomListeners;
import com.vzw.pos.automation.utilities.ApplicationUtils;
import com.vzw.pos.automation.utilities.BrowserHandler;
import com.vzw.pos.automation.utilities.SystemUtils;

public class AbstractClass extends TapsiumHandler {

 @SuppressWarnings("unchecked")
@BeforeClass
	public void envstartup(ITestContext context) throws NoDataFound, InterruptedException, IOException {
		BasePage.initiatePropertiesFiles();
		dataTable.remove("_id");
		JSONArray staticInput = new JSONArray();
		logs = new JSONArray();
		failures = new JSONArray();
		inputs = new JSONArray();
		scenarioPerformance = new JSONArray();
		pageSource = new JSONArray();
		orderStages = new JSONArray();
		validations = new JSONArray();
		screenshots = new JSONArray();
		headerInfoSAP = new JSONArray();
		itemInfoSAP = new JSONArray();
		validationSAP = new JSONArray();
		debugLogsSAP = new JSONArray();
		restRequestResponse = new JSONArray();
		testProperties = new Hashtable<>();
		staticInput.add(new JSONObject(dataTable));
		testProperties.put("staticInput", staticInput);
		testProperties.put("logs", logs);
		testProperties.put("failures", failures);
		testProperties.put("inputs", inputs);
		testProperties.put("restOperations", restRequestResponse);
		testProperties.put("scenarioPerformance", scenarioPerformance);
		testProperties.put("pageSource", pageSource);
		testProperties.put("validations", validations);
		testProperties.put("screenshots", screenshots);
		testProperties.put("headerInfoSAP", headerInfoSAP);
		testProperties.put("itemInfoSAP", itemInfoSAP);
		testProperties.put("validationSAP", validationSAP);
		testProperties.put("debugLogsSAP", debugLogsSAP);
		testProperties.put("orderStages", orderStages);
		this.transactionName = context.getName();
		if ("SAPOrders".equalsIgnoreCase(context.getName()) || "SAP_Orders".equalsIgnoreCase(context.getName())) {
			this.testDescription = returnAttribute(testProperties, "TEST_DESCRIPTION");
		} else {
			this.testDescription = returnAttribute(testProperties, "TCNumber") + "_"
					+ returnAttribute(testProperties, "ScenarioDescription");
		}
		captureGridScreenshot(dataTable);
		setProdLocationBasedUponRegion(dataTable, transactionName);
		WaitforEnv();
		initiateLogFile();		
		//TapsiumTestSession testSession = new TapsiumTestSession();
	//	testSession.initSession(testProperties, dataTable);
		
		try {
			MDC.put("collection", context.getName());			
			MDC.put("user", SystemUtils.returnUserId());
			MDC.put("buildNumber", CustomListeners.buildNumber);
			MDC.put("testcase", testDescription);
			MDC.put("channel", returnChannelName(context.getName()));
			MDC.put("env", ResultUtil.getTestEnvironment());
		} catch(Exception e) {
			//
		}
		
	}
 
 
 public void initiateBrowserFromGrid(String browserName, String gridUrl) throws Exception {
		DesiredCapabilities cap = new DesiredCapabilities();
		BrowserHandler browserHandle = new BrowserHandler();
		if (System.getProperty("browser") != null && !System.getProperty("browser").equalsIgnoreCase("No")) {
			browserName = System.getProperty("browser");
		}
		//cap = browserHandle.setDesiredCapabilities(browserName);
		initializeDesktopBrowser(gridUrl, cap);
		dataTable.put("nodeIPAddress", returnNodeIPAddress(getDriver()));
		//markScenarioAsExecuting(testDescription, transactionName);
		ReportMigrator.updateTestStatusToExecuting(testDescription, transactionName);	
	}
 

	public void initiateBrowserFromGrid(String browserName1) throws Exception {
		String browserName = browserName1;
		DesiredCapabilities cap = new DesiredCapabilities();
		BrowserHandler browserHandle = new BrowserHandler();
		if (System.getProperty("browser") != null && !System.getProperty("browser").equalsIgnoreCase("No")) {
			browserName = System.getProperty("browser");
		}
		//cap = browserHandle.setDesiredCapabilities(browserName);
		//initializeDesktopBrowser(returnGridIP(), cap);
		dataTable.put("nodeIPAddress", returnNodeIPAddress(getDriver()));
		//markScenarioAsExecuting(testDescription, transactionName);
		ReportMigrator.updateTestStatusToExecuting(testDescription, transactionName);	
	}

	public void initiateIOSAppInGrid(String appName) throws MalformedURLException, UnknownHostException, SQLException {
		DesiredCapabilities cap = new DesiredCapabilities();
		BrowserHandler browserHandle = new BrowserHandler();
	//	cap = browserHandle.setDesiredCapabilities(appName);
	//	initializeIOSApplication(returnGridIP(), cap);
		//markScenarioAsExecuting(testDescription, transactionName);
		ReportMigrator.updateTestStatusToExecuting(testDescription, transactionName);	
	}

	public void navigateToApplication() throws FileNotFoundException, NoDataFound, InterruptedException {
		ApplicationUtils initializeModule = new ApplicationUtils();
		initializeModule.openApplication(getDriver(), returnAttribute(testProperties, "ApplicationName"),
				transactionName, ResultUtil.getTestEnvironment());
	}

	public void setProdLocationBasedUponRegion(Hashtable<String, String> inputDetails, String transactionName)
			throws IOException {
		if (System.getProperty("executionEnvironment") != null && "PROD".equalsIgnoreCase(System.getProperty("executionEnvironment"))
				&& System.getProperty("region") != null) {
			inputDetails.put("LocationNum",
					returnProdLocation(returnChannelName(transactionName), System.getProperty("region")));
			inputDetails.put("Area", System.getProperty("region"));
		}
	}

}
