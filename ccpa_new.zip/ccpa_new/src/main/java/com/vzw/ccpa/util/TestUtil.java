package com.vzw.ccpa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.util.Properties;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.io.IOUtils;
import org.testng.log4testng.Logger;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;

import com.vzw.ccpa.apitest.DownloadElementsByCategoryAPI;;

public class TestUtil {
	
	public static Session session;
	public static Cluster cluster;
	static Properties config = new Properties();
	
	public static String keyspace;
	
	static Logger logger = Logger.getLogger(TestUtil.class);
	
	static {
		try {
			InputStream str = new FileInputStream("config_t2.properties");
			config.load(str);			
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	 }
	
	public static long getCurrentUnixTime() {
		return Instant.now().toEpochMilli();
	}
	
	public static String readFileAsString(String fileName) throws Exception{
		ClassLoader classLoader = DownloadElementsByCategoryAPI.class.getClassLoader();
		return IOUtils.toString(classLoader.getResourceAsStream(fileName));
	}
	
	
	  public static void openCassandraConnection() {
		  
	  System.out.println("CONNECTION INFO ::::::::::::: "+TestUtil.config.
	  getProperty("cassandra_ip") +
	  " :::::: "+TestUtil.config.getProperty("userName") +" ::::: "+
	  TestUtil.config.getProperty("password")); 
	  
	  cluster = Cluster.builder().addContactPoint(TestUtil.config.getProperty("cassandra_ip")).withCredentials(TestUtil.config.getProperty("userName"),
	  TestUtil.config.getProperty("password")).build(); 
	  session =  cluster.connect(keyspace);
	  logger.info("Established the cassandra connection");
	  
	  }
	  
	  public static ResultSet fetchDatafromCassandra(String cql) { ResultSet
	  resultSet = session.execute(cql); return resultSet; }
	 

	static int totalElementsIdentified;
	static String getURLFor;
	static String checkFlag;
	static HashMap <Integer, String> nameMapping;

	public static String readfileAsString(String fileName) throws Exception {
		ClassLoader classLoader = DownloadElementsByCategoryAPI.class.getClassLoader();
		return IOUtils.toString(classLoader.getResourceAsStream(fileName));
	}

	public static HashMap<String, String> filterElementsFromVASTReferanceData(String operation, int[] elements) throws Exception {
		HashMap<String, String> systemURLMapping = new HashMap<String, String>();
		switch (operation) {
		case ("download"): {
			getURLFor = "DownloadURL";
			checkFlag = "Downloadable";
			break;
		}
		case ("delete"): {
			getURLFor = "DeleteURL";
			checkFlag = "Deletable";
			break;
		}
		default: {
			getURLFor = "PreviewURL";
			checkFlag = "Previewable";
		}
		}

		Map<String, Object[]> elementsMappingMap = new TreeMap<String, Object[]>();
		elementsMappingMap.put("1", new Object[] { "ElementID", "UseFriendlyName", "System","ServiceInfo", getURLFor});
		int excelRow = 2;
		for (int a = 0; a < totalElementsIdentified; a++) {			
			int elementID = elements[a];
			System.out.println("Element Considered in this loop is ::: " + elementID);
			String vastRefData = TestUtil.readfileAsString("Requests/DownloadElementsByCategory/vastrefdata.json");
			JSONObject originalVASTData = new JSONObject(vastRefData);
			JSONArray availableApplications = originalVASTData.getJSONArray("Applications");
			
			HashMap<Integer, HashMap<String, String>> elementsFinalMapping = new HashMap<Integer, HashMap<String, String>>();
			String systemName;
			String serviceName;
			String downloadURL;
			for (int i = 0; i < availableApplications.length(); i++) {
				JSONObject applicationJSONObject = availableApplications.getJSONObject(i);
				systemName = applicationJSONObject.getString("Acronym");
				JSONArray serviceJSONArray = applicationJSONObject.getJSONArray("Services");
				for (int j = 0; j < serviceJSONArray.length(); j++) {
					JSONArray elementArray = serviceJSONArray.getJSONObject(j).getJSONArray("Elements");
					for (int k = 0; k < elementArray.length(); k++) {
						if (elementArray.getJSONObject(k).getInt("ID") == elementID) {
							serviceName = serviceJSONArray.getJSONObject(j).getString("Name") + " consider this "+elementArray.getJSONObject(k).getString(checkFlag);
							try {
								downloadURL = serviceJSONArray.getJSONObject(j).getString(getURLFor);
							} catch (ArrayIndexOutOfBoundsException e) {
								downloadURL = "URL is coming as empty from VAST";
							}

							systemURLMapping.put(systemName, serviceName + " and URL is " + downloadURL);
						}
					}
				}
			}
			elementsFinalMapping.put(elementID, systemURLMapping);
			// for (elementsFinalMapping.keySet()

			for (int elementSelected : elementsFinalMapping.keySet()) {
				System.out.println("----------------------------------------------------");
				System.out.println("Element ID ::: " + elementSelected);
				for (String system : elementsFinalMapping.get(elementSelected).keySet()) {
					String[] systemAndURL = elementsFinalMapping.get(elementSelected).get(system).split(" and URL is ");
					String[] systemAndURLToConsider = systemAndURL[0].split(" consider this ");
					System.out.println(system + " :: " + elementsFinalMapping.get(elementSelected).get(system));

					if (systemAndURLToConsider[1].equals("Yes")) {
						try {
							elementsMappingMap.put(String.valueOf(excelRow),
									new Object[] { String.valueOf(elementID), getUserFriendlyName(elementID), system, systemAndURLToConsider[0], systemAndURL[1]});
						} catch (ArrayIndexOutOfBoundsException e) {
							elementsMappingMap.put(String.valueOf(excelRow),
									new Object[] { String.valueOf(elementID), getUserFriendlyName(elementID), system, systemAndURLToConsider[0], "NO URL FROM REF DATA"});
						}
					}
					excelRow++;
					
				}
				System.out.println("----------------------------------------------------");
			}

		}
		System.out.println("Number of rows are " + elementsMappingMap.size());
		TestUtil.writetoExcel(elementsMappingMap);
		return systemURLMapping;
	}

	public static int[] filterElementsFromCMS(String category, String downloadType) throws Exception {
		nameMapping = new HashMap<Integer, String>();
		String cmsRefData = TestUtil.readfileAsString("Requests/DownloadElementsByCategory/cmsrefdata.json");
		// Logic to filter the date using the category
		JSONObject originalCMSData = new JSONObject(cmsRefData);
		JSONArray availableCategories = originalCMSData.getJSONArray("categories");
		System.out.println("Total number of categories available is ::: " + availableCategories.length());
		JSONObject categoryFilteredData = new JSONObject();
		for (int i = 0; i < availableCategories.length(); i++) {
			if (availableCategories.getJSONObject(i).getString("category_id").equals(category)) {
				categoryFilteredData = availableCategories.getJSONObject(i);
				break;
			}
		}
		System.out.println(categoryFilteredData);

		// Logic to filter the date using the downloadType
		JSONArray arrayofSubCategories = categoryFilteredData.getJSONArray("sub_categories");
		int[] dataElementsFiltered = new int[200];
		int k = 0;
		int totalElements = 0;
		for (int i = 0; i < arrayofSubCategories.length(); i++) {
			JSONArray dataElementsObject = arrayofSubCategories.getJSONObject(i).getJSONArray("data_element_info");
			totalElements += dataElementsObject.length();
			for (int j = 0; j < dataElementsObject.length(); j++) {
				JSONObject dataElementInfo = dataElementsObject.getJSONObject(j);
				if (downloadType == "Regular") {
					if (dataElementInfo.getInt("tier") == 1 || dataElementInfo.getInt("tier") == 2) {
						dataElementsFiltered[k] = dataElementInfo.getInt("unique_element");
						nameMapping.put(dataElementInfo.getInt("unique_element"), dataElementInfo.getString("user_friendly_name"));
						k++;
					}
				} else if (downloadType == "Affidavit") {
					if (dataElementInfo.getInt("tier") == 1 || dataElementInfo.getInt("tier") == 2
							|| dataElementInfo.getInt("tier") == 3 || dataElementInfo.getInt("tier") == 4) {
						dataElementsFiltered[k] = dataElementInfo.getInt("unique_element");
						nameMapping.put(dataElementInfo.getInt("unique_element"), dataElementInfo.getString("user_friendly_name"));
						k++;
					}
				}
			}
		}
		System.out.println("Total number of data elements present is " + totalElements);
		System.out.println("Total number of applicable data elements are " + k);
		for (int i = 0; i < k; i++) {
			System.out.println(dataElementsFiltered[i]);
		}
		totalElementsIdentified = k;
		return dataElementsFiltered;
	}
	
	public static String getUserFriendlyName (int elementID) {		
		return nameMapping.get(elementID);
	}
	
	public static int[] filterElementsFromCMS(String[] category, String downloadType) throws Exception {
		int k = 0;
		int totalElements = 0;
		int[] dataElementsFiltered = new int[200];		
		String cmsRefData = TestUtil.readfileAsString("Requests/DownloadElementsByCategory/cmsrefdata.json");
		// Logic to filter the date using the category
		JSONObject originalCMSData = new JSONObject(cmsRefData);
		JSONArray availableCategories = originalCMSData.getJSONArray("categories");
		System.out.println("Total number of categories available is ::: " + availableCategories.length());
		JSONObject categoryFilteredData = new JSONObject();		
		for (int a = 0; a < category.length;a++) {
			for (int i = 0; i < availableCategories.length(); i++) {
				if (availableCategories.getJSONObject(i).getString("category_id").equals(category[a])) {
					categoryFilteredData = availableCategories.getJSONObject(i);
					break;
				}
			}
			System.out.println(categoryFilteredData.toString());

			// Logic to filter the date using the downloadType
			JSONArray arrayofSubCategories = categoryFilteredData.getJSONArray("sub_categories");		
			
			for (int i = 0; i < arrayofSubCategories.length(); i++) {
				JSONArray dataElementsObject = arrayofSubCategories.getJSONObject(i).getJSONArray("data_element_info");
				totalElements += dataElementsObject.length();
				for (int j = 0; j < dataElementsObject.length(); j++) {
					JSONObject dataElementInfo = dataElementsObject.getJSONObject(j);
					if (downloadType == "Regular") {
						if (dataElementInfo.getInt("tier") == 1 || dataElementInfo.getInt("tier") == 2) {
							dataElementsFiltered[k] = dataElementInfo.getInt("unique_element");
							k++;
						}
					} else if (downloadType == "Affidavit") {
						if (dataElementInfo.getInt("tier") == 1 || dataElementInfo.getInt("tier") == 2
								|| dataElementInfo.getInt("tier") == 3 || dataElementInfo.getInt("tier") == 4) {
							dataElementsFiltered[k] = dataElementInfo.getInt("unique_element");
							k++;
						}
					}
				}
			}
		}
		
		
		System.out.println("Total number of data elements present is " + totalElements);
		System.out.println("Total number of applicable data elements are " + k);
		for (int i = 0; i < k; i++) {
			System.out.println(dataElementsFiltered[i]);
		}
		totalElementsIdentified = k;
		return dataElementsFiltered;
	}

	public static void writetoExcel(Map<String, Object[]> empinfo) throws IOException {
		// Create blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();

		// Create a blank sheet
		XSSFSheet spreadsheet = workbook.createSheet(" Employee Info ");

		// Create row object
		XSSFRow row;

		// Iterate over data and write to sheet
		Set<String> keyid = empinfo.keySet();
		int rowid = 0;

		for (String key : keyid) {
			row = spreadsheet.createRow(rowid++);
			Object[] objectArr = empinfo.get(key);
			int cellid = 0;

			for (Object obj : objectArr) {
				Cell cell = row.createCell(cellid++);
				cell.setCellValue((String) obj);
			}
		}
		// Write the workbook in file system
		FileOutputStream out = new FileOutputStream(new File("CCPA_ElementsMappingSheet.xlsx"));

		workbook.write(out);
		out.close();
		System.out.println("CCPA_ElementsMappingSheet created successfully!!!");
	}

}
