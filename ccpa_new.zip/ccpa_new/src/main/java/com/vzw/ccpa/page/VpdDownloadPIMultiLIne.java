	package com.vzw.ccpa.page;
	
	import java.io.FileNotFoundException;
	import java.util.Hashtable;
	import java.util.Set;
	import java.util.concurrent.TimeUnit;
	
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
	
	import com.fasterxml.classmate.util.ResolvedTypeCache.Key;
	import com.vzw.pos.automation.drivers.BasePage;
	
	public class VpdDownloadPIMultiLIne extends BasePage {
		
		
	
		private WebDriver driver;
		
		@FindBy(xpath="//a[@class='vpd_aem_react_link']")
		WebElement chickHistory;
		
		@FindBy(xpath="//button[@role='link']")
		WebElement GoBack;
			
		@FindBy(xpath="//*[@id='root']//button[.='Download personal information']/img")
		WebElement clickon_downloadpi;
		
		@FindBy(css="//body[@class='js-focus-visible ReactModal__Body--open']/div[@class='Modal sc-VigVT chthwX']/div[@class='ReactModal__Overlay ReactModal__Overlay--after-open Modal sc-VigVT chthwX__overlay']/div[@class='ReactModal__Content ReactModal__Content--after-open Modal sc-VigVT chthwX__content']/button[@class='sc-jTzLTM cqtPCW']/*[1]")
		WebElement clickonalert;
		
		@FindBy(xpath="//a[.='Continue']")
		WebElement clickon_continuebtn;
		
		@FindBy(xpath="//label[contains(text(),'Account and identity')]/span")
		WebElement check_account_Identity;
		
		//@FindBy(name="sensitivitySelection")
		//WebElement lvlof_download;
		
		@FindBy(xpath="//input[@value='standard']")
		WebElement Radio_Standard_Click;
		
		@FindBy(xpath="//button[.='Continue']")
		WebElement click_2ndcontinue;
		
		@FindBy(xpath="//*[@id=\"root\"]/div[3]/div/div/fieldset/ul/li[1]/label/span/span[2]")
			//	+ "((//span[@class='device_selection_span'])[1]/span[2]")
		WebElement selectphone;
		
		
		@FindBy(xpath="//button[.='Continue']")
		WebElement click_continue3;
		
		@FindBy(xpath="//button[.='Request code']")
		WebElement click_request_code;
		
		@FindBy(xpath="//*[@id='accordion__heading-4']")
		WebElement clickion_personalinfo;
		
		@FindBy(xpath="#root > div:nth-child(3) > div > div > button")
		WebElement clcikrequet;
	
		
		@FindBy(xpath="//*[@id=\'j_username\']")
		WebElement amusername;
		
		@FindBy(xpath="//*[@id=\'j_password\']")
		WebElement AmPass;
		
		@FindBy(xpath="//*[@id='submit']")
		WebElement Amsubmit;
		
		@FindBy(xpath="//*[@id='sidebar']/ul/li[1]/a")
		WebElement AM_Login;
		
		@FindBy(xpath="//*[@id='sidebar']/ul/li[5]/a")
		WebElement SmartPinReset;
		
		@FindBy(xpath="//*[@id='vpd']")
		WebElement SelectAmCategory;
		
		@FindBy(xpath="//*[@id='displayAccountNumber']/input")
		WebElement  AccntNO;
		
		@FindBy(xpath="/html/body/div[2]/form/input")
		WebElement  Searchaccount;
		
		@FindBy(xpath="//span[contains(text(),'PIN')]/following-sibling::text()[1]")
		WebElement  searchPin;
		
		@FindBy(xpath="/html/body/form/div/text()[6]")
		WebElement  pintnumber;
		
		@FindBy(xpath="//input[@value='Create New PIN']")
		WebElement creatpin;
		
		//@FindBy(xpath="#root > div:nth-child(3) > div > div > button")
		//WebElement requestcode;
		@FindBy(css="#root > div:nth-child(3) > div > div > button")
		WebElement request_code;
		
		@FindBy(xpath ="//button[@class='sc-bdVaJa sc-bwzfXH sc-gPEVay kqYmsL sc-EHOje fQHGpj']")
		WebElement request_code1;
		
		@FindBy(xpath="//input[@id='multifactor_authentication']")
		WebElement eNterMFA;
		
		@FindBy(css="#root > div:nth-child(3) > div > div > div > div > div:nth-child(3) > form > button")
		WebElement EnterAutorizationcode;
		
		
		@FindBy(xpath="//button[.='Continue']")
		WebElement SelectSelect_a_date_range;
	    
		@FindBy(xpath="//input[@value='json']")
		WebElement fileFormatLikeToReceive;
		
		@FindBy(xpath="//button[.='Continue']")
		WebElement subMiTDownloadRequest;
		
		@FindBy(xpath="//button[.='Submit request']")
		WebElement SubMitDone;
		
		@FindBy(xpath="//button[.='Done']")
		WebElement click_Done;
		
		Hashtable<String, String> hTable;
		
		public VpdDownloadPIMultiLIne(WebDriver driver,Hashtable<String, String> table) {
			this.driver=driver;
			PageFactory.initElements(driver, this);
			this.hTable=table;
		}
		public void vPDown() throws FileNotFoundException, InterruptedException {
			SoftAssert softAssert = new SoftAssert();
				try {
					Thread.sleep(5000);
	
			clickonElement(driver,chickHistory,"Pass: user able to check MDN related history", "User unable to check MDN related history");
			softAssert.assertEquals("Delete", "Download");
			clickonElement(driver,GoBack,"Pass","Fail");
				}
				catch (Exception e){
					e.printStackTrace();
				}
				WebDriverWait wait = new WebDriverWait(driver, 15);
				wait.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));				
				clickonElement(driver,clickon_downloadpi,"Pass:","Fail");
					   
			//	clickonElement(driver,clickonalert,"Pass","Fail");
				
				Thread.sleep(7000);
				clickonElement(driver,clickon_continuebtn,"Pass: user able to click on continue button","Fail: user not able to click on continue button");
				
				System.out.println("Continue button is exist");
				
					Thread.sleep(7000);
				clickonElement(driver,check_account_Identity,"Pass: user able to click on check_account_Identity ","Fail: user not able to click on check_account_Identity");
				
				clickonElement(driver,Radio_Standard_Click,"Pass: user able to click on levelof download standard radio button","Fail: user not able to click on levelof download standard radio ");
				
				clickonElement(driver,click_2ndcontinue,"Pass: user able to click on levelof download standard radio button ","Fail: user not able to click on levelof download standard radio ");
				Thread.sleep(7000);
				clickonElement(driver,selectphone,"Pass: user able to click on selected phone","Fail: user ubable to click to select phone");
				clickonElement(driver,click_continue3,"Pass","fail");
				Thread.sleep(7000);
				clickonElement(driver,click_request_code,"pass:","Fail:");
		
				try {
				
			
			//clickonElement(driver,request_code1,"pass","fail");
			    Thread.sleep(7000);
		
			String currentWindow = driver.getWindowHandle();
			Set<String> windows = driver.getWindowHandles();
			for(String s:windows) {
				if(!currentWindow.equals(s)) {
					driver.switchTo().window(s);
					System.out.println("Now Amtool begans");
					setElement(driver,amusername,hTable.get("Am_User"),"Pass: user able to enter username","Fail User unable to enter username");
					setElement(driver,AmPass,hTable.get("Am_Pass"),"Pass:user able to enter password","Fail user unable to enter password");
					clickonElement(driver,Amsubmit,"Pass: user able to click on submit button On Amtool","Fail: user not able to click on submit button on Amtool");
					clickonElement(driver,AM_Login,"Pass: user able to click on Amtool Login Link","Fail: user not able to click on Amtool Login Link");
					clickonElement(driver,SmartPinReset,"Pass: user able to click on Smartpin Reset link","Fail: user not able to click on Smartpin Reset Link");
				}
				}
				
				}catch(Exception ex) {
				System.out.println("reach to next tab");
				}
			
			
	
				try {
					//Select category = new Select(driver.findElement(By.name("client")));
					//category.selectByVisibleText("Verizon Privacy Dashboard");
					WebElement as = driver.findElement(By.cssSelector("iframe[name='toolsContent']"));
					driver.switchTo().frame(as);
					
					
					clickonElement(driver,SelectAmCategory,"Pass: user able to Select option","Fail: user unable to Select option");
									
					setElement(driver,AccntNO,hTable.get("AccountNO"),"Pass: user able to enter account value","Fail: user unable to enter to account value");
				
					clickonElement(driver,Searchaccount,"Pass: user able to click on seacrhbutton on accountsearch","Fail: user not able to click on seacrhbutton on accountsearch");
					//selectOptionByElementText(driver,pintnumber));
					 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//waits for 3 seconds
					 Thread.sleep(7000);
					 clickonElement(driver,creatpin,"Pass: user able to click create pin button","Fail: unsuccessfully click on creae ping button");
					 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
					
					//clickonElement(driver,request_code1,"Pass: User able to click on request code","Fail: user unale to clcik on request code");
					
					Thread.sleep(7000);
					driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
					String HeaderTxt = driver.findElement(By.cssSelector("body:nth-child(2) form:nth-child(7) > div.profileresultleft:nth-child(7)")).getText();
							
						String[] arr1=HeaderTxt.split("PIN: ");
							
						String[] arr2=arr1[1].split("\n"); 
						String strPin=arr2[0];
						
						System.out.println("This is the Pin:"+strPin);	
						//int result = Integer.parseInt(strPing);						
						String currentWindow1 = driver.getWindowHandle();
						Set<String> windows1 = driver.getWindowHandles();
						for(String s1:windows1) {
							if(!currentWindow1.equals(s1)) {
								driver.switchTo().window(s1);
								//clickonElement(driver,request_code1,"pass","fail");
								driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
								Thread.sleep(7000);
								hTable.put("Pin",strPin);
								
						
						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						
						//driver.findElement(By.xpath("#multifactor_authentication")).sendKeys("strPing");
						Thread.sleep(7000);
						setElement(driver,eNterMFA,strPin,"Pass:user able to enter pin umber","Fail user unable to enter pin number");
						clickonElement(driver,EnterAutorizationcode,"Pass user able to click on Continue button after enter MFA code","Fail:User unable to  click on Continue button after enter MFA code");
						WebDriverWait wait1 = new WebDriverWait(driver, 15);
						wait1.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));
						clickonElement(driver,SelectSelect_a_date_range,"Pass","Fail");
						WebDriverWait wait13 = new WebDriverWait(driver, 15);
						wait13.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));
						clickonElement(driver,fileFormatLikeToReceive,"Pass","Fail");
						WebDriverWait wait11 = new WebDriverWait(driver, 15);
						wait11.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));
						clickonElement(driver,subMiTDownloadRequest,"pass","fail");
						WebDriverWait wait12 = new WebDriverWait(driver, 15);
						wait12.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));
						
						WebDriverWait wait2 = new WebDriverWait(driver, 15);
						wait2.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));
						clickonElement (driver,SubMitDone,"pass","Fail");
						supressAlerts();
						clickonElement(driver,click_Done,"Pass","Fail");
						
						softAssert.assertAll();
	
							}							
							}
		
						}
						catch (Throwable e1) {
						e1.printStackTrace();
						
						
											
	
							}
	
	
				
			
						}
	
	
						}
	
	
					
	
					
						
				
				
					
				
				
				
								
				
			   
			
	
	
	
		 
		
	
		
		
		
	
	
