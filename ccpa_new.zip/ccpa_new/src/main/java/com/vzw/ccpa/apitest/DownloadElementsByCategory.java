
package com.vzw.ccpa.apitest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.beust.jcommander.Strings;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.vzw.ccpa.util.TestUtil;
import com.vzw.pos.automation.drivers.AbstractClass;
import com.vzw.pos.automation.utilities.TestDataProvider;

public class DownloadElementsByCategory
//  extends AbstractClass implements
//  ITest{ 
{

	static Logger logger = Logger.getLogger(TestUtil.class);

	HttpResponse response_ra;
	static String requestBody;

	RequestBuilder requestBuilder;
	String resultdata;
	String downloadID;

	static String xapiKey_t2 = "e9w95uLJ8hyc9bk9Bf9tuAsGQGXOEHlN";
	static String baseURL = "https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core";
	String service_uri = "https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core/downloadElementsByCategories";
	List<String> trackingIDs = new ArrayList<>();
	HashMap<String, String> systemMapping = new HashMap<String, String>();

	String accountID = "280120311-00001";
	String requestedRole = "accountHolder";
	String requested_mtn = "5857045843";
	String requestedCategories = "accountinfo";

	@BeforeClass
	public void initTest() {
		TestUtil.keyspace = "vzw_ccpa";
		TestUtil.openCassandraConnection();
		RestAssured.baseURI = baseURL;

	}

//  @Factory(dataProviderClass = TestDataProvider.class, dataProvider =
//  "testScenarios") public TestClass(Hashtable<String, String> table) {
//  this.dataTable = table; }

	// To make the API calls using rest assured

	@Test(priority = 0)
	public void invokeDownloadElementsByCategory() throws Exception {
		RequestSpecification request = RestAssured.given();
		requestBody = TestUtil.readFileAsString("Requests/DownloadElementsByCategory/baseRequest.json");
		// Changing the request parameters
		requestBody = requestBody.replaceAll("accountId_val", accountID);
		requestBody = requestBody.replaceAll("requestedRole", requestedRole);
		requestBody = requestBody.replaceAll("requested_mtn", requested_mtn);
		requestBody = requestBody.replaceAll("requestedCategories", requestedCategories);

		request.header("Content-Type", "application/json");
		request.header("correlationId", TestUtil.getCurrentUnixTime());
		request.header("x-apikey", xapiKey_t2);

		request.body(requestBody);
		Response response = request.post("/downloadElementsByCategories");

		System.out.println("Status Code from rest assured call is " + response.getStatusCode());
		System.out.println("Response is :: " + response.body().asString());
		
		Assert.assertEquals(200, response.getStatusCode());
		
		JSONObject downloadedData = new JSONObject(response.body().asString());
		downloadID = downloadedData.getString("uniqueDownloadId");
		System.out.println("unique downlod Id is : " + downloadID);
		logger.info("unique downlod Id is : " + downloadID);
		
		
		int[] elements = TestUtil.filterElementsFromCMS("", "Regular");
	}

	@Test(priority = 1)
	public void testDBConnection() throws Exception {
		// can call download API functionality
		HashMap<String, String> requestStatus = new HashMap<String, String>();
		String transId = "433f7db8-0529-46b3-94c7-314354e7ea90";
		// downloadID;
		System.out.println("Download ID here is " + transId);
		String cqlStatement = "select * from async_txn_tracking_by_txn_id where txn_id in ('" + transId + "')";
		ResultSet resultSet = TestUtil.fetchDatafromCassandra(cqlStatement);
		System.out.println("Available columns are ::: " + resultSet.getColumnDefinitions());
		for (Row row : resultSet) {
			requestStatus.put(row.getString("system"), row.getString("status"));
			trackingIDs.add("\"" + row.getString("tracking_id") + "\"");
		}
		System.out.println(trackingIDs.toString());
		System.out.println("Applicable systems from DB are :: " + requestStatus.keySet());
		verifyApplicableSystemInfo();
		verifySystemStatus(requestStatus, "PENDING_PROCESS");
		String[] systemListFromCMS = systemMapping.keySet().stream().collect(Collectors.toList())
				.toArray(new String[100]);
		String[] systemListFromDatabase = requestStatus.keySet().stream().collect(Collectors.toList())
				.toArray(new String[100]);
		Arrays.parallelSort(systemListFromCMS);
		Arrays.parallelSort(systemListFromDatabase);
		Assert.assertEquals(systemListFromCMS, systemListFromDatabase);
	}

	public void verifySystemStatus(HashMap<String, String> responseFromDB, String status) {
//		List<String> personsSorted =
//  items.stream().collect(Collectors.toList());
//  Assert.assertTrue(Collections.sort(responseFromDB.keySet());
		for (String system : systemMapping.keySet()) {
			Assert.assertEquals(responseFromDB.get(system) == null ? status : responseFromDB.get(system), status,
					"Asserting " + system + " status");
		}
	}

	// Check for filter categories to be be filtered from CMS
	public void verifyApplicableSystemInfo() throws Exception {
		String[] categories = requestedCategories.split(",");
		int[] elements = TestUtil.filterElementsFromCMS(categories[0], "Regular");
		systemMapping = TestUtil.filterElementsFromVASTReferanceData("download", elements);
	}

	@Test(priority = 2)
	public void testAdhocRequestAPI() throws Exception {
		RestAssured.baseURI = baseURL;
		RequestSpecification request = RestAssured.given();

		requestBody = TestUtil.readFileAsString("Requests/DownloadElementsByCategory/adhocRequest.json");
		requestBody = requestBody.replaceAll("correlationId_val", Long.toString(TestUtil.getCurrentUnixTime()));
		requestBody = requestBody.replaceAll("tracking_ids", String.join(" , ", trackingIDs));

		request.header("Content-Type", "application/json");
		request.header("correlationId", TestUtil.getCurrentUnixTime());
		request.header("x-apikey", xapiKey_t2);

		request.body(requestBody);
		Response response = request.post("/adhocDownloadElements");
		Assert.assertEquals(200, response.getStatusCode());
		JSONObject adhocResponse = new JSONObject(response.body().asString());
		JSONArray acceptedTrackindIds = adhocResponse.getJSONArray("acceptedTrackindIds");
		List<String> listAcceptedTrackIds = new ArrayList<String>();
		for (int i = 0; i < acceptedTrackindIds.length(); i++) {
			String acceptedId = acceptedTrackindIds.get(i).toString();
			listAcceptedTrackIds.add(acceptedId);
		}

		Collections.sort(listAcceptedTrackIds);
		List<String> listTrackIds = trackingIDs.stream().map((eachStr) -> eachStr.substring(1, eachStr.length()))
		.collect(Collectors.toList());
		Collections.sort(listTrackIds);

	}

	@AfterClass
	public void tearDown() {
		TestUtil.cluster.close();
		TestUtil.session.close();
	}

	public static void main(String[] args) throws Exception { //
		String[] categories = { "accountinfo", "networkactivity", "collectedinferences", "addons" }; //
		int[] elements = TestUtil.filterElementsFromCMS(categories, "Regular"); //
		int[] elementsDup = TestUtil.filterElementsFromCMS("accountInfo", "Affidavit"); //
		TestUtil.filterElementsFromVASTReferanceData("download", elements); //
		String cql = "select * from async_txn_tracking_by_txn_id where txn_id in ('6f08c4dc-7922-4cc8-bb3d-7d60af1934f6')";
		TestUtil.openCassandraConnection();

		ResultSet results = TestUtil.fetchDatafromCassandra(cql); //
		System.out.println(results.toString());

	}

}
