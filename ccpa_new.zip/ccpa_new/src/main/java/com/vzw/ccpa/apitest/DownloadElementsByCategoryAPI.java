package com.vzw.ccpa.apitest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.RequestBuilder;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.vzw.ccpa.page.LoginPage;
import com.vzw.ccpa.util.TestUtil;
import com.vzw.pos.automation.constants.FailureConstants;
import com.vzw.pos.automation.drivers.AbstractClass;
import com.vzw.pos.automation.exceptions.TapsiumCatchBlock;
import com.vzw.pos.automation.exceptions.TapsiumFinalBlock;
import com.vzw.pos.automation.utilities.TestDataProvider;

public class DownloadElementsByCategoryAPI extends AbstractClass implements ITest{
	
	HttpResponse response_ra;
	static String requestBody;

	RequestBuilder requestBuilder;
	String resultdata;
	String downloadID;

	static String xapiKey_t2 = "e9w95uLJ8hyc9bk9Bf9tuAsGQGXOEHlN";
	static String baseURL = "https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core";
	String service_uri = "https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core/downloadElementsByCategories";
	List<String> trackingIDs = new ArrayList<>();
	HashMap<String, String> systemMapping = new HashMap<String, String>();
	
	private Logger logger = LoggerFactory.getLogger(DownloadElementsByCategoryAPI.class);
	
	@Factory(dataProviderClass = TestDataProvider.class, dataProvider = "testScenarios")
	public DownloadElementsByCategoryAPI(Hashtable<String, String> table) {
		this.dataTable = table;
	}
	
	@BeforeClass
	public void initTest() {
		TestUtil.keyspace = "vzw_ccpa";
		TestUtil.openCassandraConnection();
		RestAssured.baseURI = baseURL;

	}
	
	/*
	 * public void verifySystemStatus(HashMap<String, String> responseFromDB, String
	 * status) { List<String> personsSorted =
	 * items.stream().collect(Collectors.toList());
	 * Assert.assertTrue(Collections.sort(responseFromDB.keySet()); for (String
	 * system:systemMapping.keySet()) {
	 * Assert.assertEquals("Asserting "+system+" status",
	 * responseFromDB.get(system), "PENDING_PROCESS"); } }
	 */
	
	public void verifyApplicableSystemInfo() throws Exception {
		String[] categories = dataTable.get("RequestedCategories").split(",");
		int[] elements = TestUtil.filterElementsFromCMS(categories, "Regular");
		systemMapping = TestUtil.filterElementsFromVASTReferanceData("download", elements);		
	}
	/*
	@Test
	public void testAdhocRequestAPI() throws Exception {
		RestAssured.baseURI = baseURL;
		RequestSpecification request = RestAssured.given();

		requestBody = TestUtil.readFileAsString("Requests/DownloadElementsByCategory/adhocRequest.json");
		requestBody = requestBody.replaceAll("correlationId_val", Long.toString(TestUtil.getCurrentUnixTime()));
		requestBody = requestBody.replaceAll("tracking_ids", String.join(" , ", trackingIDs));


		request.header("Content-Type", "application/json");
		request.header("correlationId", TestUtil.getCurrentUnixTime());
		request.header("x-apikey", xapiKey_t2);

		request.body(requestBody);
		Response response = request.post("/adhocDownloadElements");
		Assert.assertEquals(200, response.getStatusCode());

	}*/
	
	@Test
	public void invokeDownloadElementsByCategory() throws Exception {		
		RequestSpecification request = RestAssured.given();
		requestBody = TestUtil.readFileAsString("Requests/DownloadElementsByCategory/baseRequest.json");
		//Changing the request parameters
		requestBody = requestBody.replaceAll("accountId_val", dataTable.get("AccountID"));		
		requestBody = requestBody.replaceAll("requestedRole", dataTable.get("RequestedRole"));
		requestBody = requestBody.replaceAll("requested_mtn", dataTable.get("requested_mtn"));
		requestBody = requestBody.replaceAll("requestedCategories",dataTable.get("RequestedCategories"));

		request.header("Content-Type", "application/json");
		request.header("correlationId", TestUtil.getCurrentUnixTime());
		request.header("x-apikey", xapiKey_t2);

		request.body(requestBody);
		Response response = request.post("/downloadElementsByCategories");
		
		logger.info("Status Code from rest assured call is " + response.getStatusCode());
		logger.info("Response is :: " + response.body().asString());
		JSONObject downloadedData = new JSONObject(response.body().asString());
		downloadID = downloadedData.getString("uniqueDownloadId");
		logger.info("unique downlod Id is : " + downloadID);
		logger.info("unique downlod Id is : " + downloadID);
		Assert.assertEquals(200, response.getStatusCode());
	}

	/*
	@Test
	public void testDBConnection() throws Exception {
		// can call download API functionality
		HashMap<String, String> requestStatus = new HashMap<String, String>();		
		String transId = downloadID;
		String cqlStatement = "select * from async_txn_tracking_by_txn_id where txn_id in ('" + transId + "')";
		ResultSet resultSet = TestUtil.fetchDatafromCassandra(cqlStatement);
		System.out.println("Available columns are ::: " + resultSet.getColumnDefinitions());
		for (Row row : resultSet) {
			requestStatus.put(row.getString("system"), row.getString("status"));
			trackingIDs.add("\"" + row.getString("tracking_id") + "\"");
		}
		System.out.println("Applicable systems from DB are :: " + requestStatus.keySet());		
	}
	*/

	public String getTestName() {
		return dataTable.get("TCNumber").trim() + "_" + dataTable.get("ScenarioDescription");
	}
}