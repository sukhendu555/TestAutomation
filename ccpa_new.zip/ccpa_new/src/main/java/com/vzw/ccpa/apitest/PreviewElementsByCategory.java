
package com.vzw.ccpa.apitest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.RequestBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.vzw.ccpa.util.TestUtil;
import com.vzw.pos.automation.drivers.AbstractClass;

public class PreviewElementsByCategory
//extends AbstractClass implements ITest 
{

//	static Logger logger = Logger.getLogger(TestUtil.class);

	HttpResponse response_ra;
	static String requestBody;

	RequestBuilder requestBuilder;
	String resultdata;
	String downloadID;

	static String xapiKey_t2 = "e9w95uLJ8hyc9bk9Bf9tuAsGQGXOEHlN";
	static String baseURL = "https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core";
	String service_uri = "https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core/getElementsByCategories";
//  List<String> trackingIDs = new ArrayList<>();

	private String accountID = "281852493-1";

	private String mtnNumber = "4194101361";

	private String categoryKey = "accountinfo";

//	@AfterClass
//	public void tearDown() {
//		TestUtil.cluster.close();
//		TestUtil.session.close();
//	}

	@Test
	public void validatePreviewElementsByCategory() throws Exception {
		List<Integer> allElementIds = new ArrayList<>();
		RestAssured.baseURI = baseURL;
		RequestSpecification request = RestAssured.given();
		requestBody = TestUtil.readFileAsString("Requests/PreviewElementsByCategory/baseRequest.json");
		// Changing the request parameters
		requestBody = requestBody.replaceAll("accountId_value", accountID);
		requestBody = requestBody.replaceAll("mtn_value", mtnNumber);
		requestBody = requestBody.replaceAll("categoryKey_value", categoryKey);

		request.header("Content-Type", "application/json");
		request.header("correlationId", TestUtil.getCurrentUnixTime());
		request.header("x-apikey", xapiKey_t2);

		request.body(requestBody);
		Response response = request.post("/getElementsByCategory");

		System.out.println("Status Code from rest assured call is " + response.getStatusCode());
		Assert.assertEquals(200, response.getStatusCode());
		System.out.println("Response is :: " + response.body().asString());
		JSONObject previewData = new JSONObject(response.body().asString());

		JSONArray categoryValue = previewData.getJSONArray("categoryValue");
		for (int iterVal = 0; iterVal < categoryValue.length(); iterVal++) {
			JSONObject eachSubCategory = categoryValue.getJSONObject(iterVal);
			JSONArray subCategoryValue = eachSubCategory.getJSONArray("subCategoryValue");
			for (int sub_iter = 0; sub_iter < subCategoryValue.length(); sub_iter++) {
				int elementId = Integer.parseInt(subCategoryValue.getJSONObject(sub_iter).getString("elementId"));
				allElementIds.add(elementId);
			}
		}
		System.out.println("Element IDs are " + allElementIds);
		// Int size should be dynamically created
		int[] elementIdsAsInt = new int[allElementIds.size()];
		for (int i = 0; i < allElementIds.size(); i++) {
			elementIdsAsInt[i] = allElementIds.get(i);
		}
		int[] elements = TestUtil.filterElementsFromCMS(categoryKey, "Regular");
		ArrayList<Integer> vastRefDataPreviewavleElements = new ArrayList<Integer>();
		String vastRefData = TestUtil.readfileAsString("Requests/DownloadElementsByCategory/vastrefdata.json");
		JSONObject originalVASTData = new JSONObject(vastRefData);
		JSONArray apps = originalVASTData.getJSONArray("Applications");
		for (int i = 0; i < apps.length(); i++) {
			JSONObject eachApp = apps.getJSONObject(i);
			JSONArray services = eachApp.getJSONArray("Services");
			for (int j = 0; j < services.length(); j++) {
				JSONObject eachService = services.getJSONObject(j);
				JSONArray elementsVastRef = eachService.getJSONArray("Elements");
				for (int k = 0; k < elementsVastRef.length(); k++) {
					JSONObject eachElement = elementsVastRef.getJSONObject(k);
					if (allElementIds.contains(eachElement.getInt("ID"))
							&& eachElement.getString("Previewable").equalsIgnoreCase("Yes")) {
						System.out.println("Previwable ID is " + eachElement.getInt("ID"));
						if (!vastRefDataPreviewavleElements.contains(eachElement.getInt("ID"))) {
							vastRefDataPreviewavleElements.add(eachElement.getInt("ID"));
						}
					}

				}

			}
		}

		Arrays.parallelSort(elementIdsAsInt);
		int[] vastRefDataPreviewavleElementsArray = new int[vastRefDataPreviewavleElements.size()];
		for (int i = 0; i < vastRefDataPreviewavleElementsArray.length; i++) {
			vastRefDataPreviewavleElementsArray[i] = vastRefDataPreviewavleElements.get(i);
		}
		Arrays.parallelSort(vastRefDataPreviewavleElementsArray);
		Assert.assertEquals(elementIdsAsInt, vastRefDataPreviewavleElementsArray);

	}

//	@Override
	public String getTestName() {
		return this.getClass().getCanonicalName();
	}

}
