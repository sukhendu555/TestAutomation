package ccpaapi;



import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;



@SuppressWarnings("deprecation")
public class GetData 
	
	{ 
		@Test
		public void testResponsecode()
		
		{ 
			Response resp=RestAssured.get(" e9w95uLJ8hyc9bk9Bf9tuAsGQGXOEHlN");
			
			int code = resp.getStatusCode(); 
			
			System.out.println("Stauts code is "+code);
			
			Assert.assertEquals(code, code);
			
		}
		
		@Test 
		public void testbody() {
			
			Response resp = RestAssured.post("https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core/getElementsByCategory");
			String data=resp.asString();
			System.out.println("Data is"+data);
			
			System.out.println("Response time"+resp.getTime());
		}
		@Test
		public void Preview()
		{		
			RestAssured.baseURI ="https://oa-uat.ebiz.verizon.com/b6vv-ccpa-apiproxy/QA1/ccpa-core/getElementsByCategory";
			RequestSpecification request = RestAssured.given();

			JSONObject requestParams = new JSONObject();
			requestParams.put("accountId", "1112821");
			requestParams.put("mtn", "6096050428");
			requestParams.put("role", "accountHolder");
			requestParams.put("serviceType", "vzw");
			requestParams.put("requestChannel",  "VPD");
			requestParams.put("loggedInMtn",  "6096050428");
			requestParams.put("categoryKey",  "");
			requestParams.put("mtnEffectiveDate",  "");
			request.body(requestParams.toString());
			Response response = request.post("Preview");
		}
	
	}


