package chk;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		
		ArrayList<String>  subCatList=new ArrayList<String>();
		subCatList.add("Contact Information and Personal Identifiers");
		subCatList.add("Government identifiers");
		subCatList.add("Billing and Financial Information");
		subCatList.add("Technical identifiers");
		
		if(subCatList.contains("Technical identifiers  ")) {
			System.out.println("------------------------------------------");
		}else {
			System.out.println("No match found !!");
		}
	}
	
}
